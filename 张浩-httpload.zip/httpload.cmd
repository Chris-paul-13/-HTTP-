@echo off
node "%~dp0bin\httpload.js" %*
