const MAX_TIMER_MS = 2_147_483_647;

export class CliError extends Error {
  constructor(message) {
    super(message);
    this.name = 'CliError';
  }
}

export function parseDuration(value) {
  if (typeof value !== 'string') {
    throw new CliError('timeout must be a duration such as 500ms, 2s, or 1m');
  }

  const match = /^(\d+(?:\.\d+)?)(ms|s|m)$/i.exec(value.trim());
  if (!match) {
    throw new CliError('timeout must be a duration such as 500ms, 2s, or 1m');
  }

  const multipliers = { ms: 1, s: 1_000, m: 60_000 };
  const milliseconds = Number(match[1]) * multipliers[match[2].toLowerCase()];

  if (!Number.isFinite(milliseconds) || milliseconds <= 0) {
    throw new CliError('timeout must be greater than 0');
  }
  if (milliseconds > MAX_TIMER_MS) {
    throw new CliError(`timeout must not exceed ${MAX_TIMER_MS}ms`);
  }

  return milliseconds;
}

function parsePositiveInteger(value, optionName) {
  if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
    throw new CliError(`${optionName} must be a positive integer`);
  }

  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed)) {
    throw new CliError(`${optionName} is too large`);
  }
  return parsed;
}

function requireValue(argv, index, optionName, inlineValue) {
  if (inlineValue !== undefined) {
    if (inlineValue.length === 0) {
      throw new CliError(`${optionName} requires a value`);
    }
    return { value: inlineValue, nextIndex: index };
  }

  const value = argv[index + 1];
  if (value === undefined) {
    throw new CliError(`${optionName} requires a value`);
  }
  return { value, nextIndex: index + 1 };
}

export function parseCliArgs(argv) {
  const raw = {};

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];

    if (argument === '--help' || argument === '-h') {
      return { help: true };
    }
    if (argument === '--version' || argument === '-v') {
      return { version: true };
    }

    const separatorIndex = argument.indexOf('=');
    const option = separatorIndex >= 0 ? argument.slice(0, separatorIndex) : argument;
    const inlineValue = separatorIndex >= 0 ? argument.slice(separatorIndex + 1) : undefined;

    const optionMap = {
      '--url': 'url',
      '-u': 'url',
      '--requests': 'requests',
      '-n': 'requests',
      '--concurrency': 'concurrency',
      '-c': 'concurrency',
      '--timeout': 'timeout',
      '-t': 'timeout',
    };
    const key = optionMap[option];
    if (!key) {
      throw new CliError(`unknown option: ${argument}`);
    }

    const resolved = requireValue(argv, index, option, inlineValue);
    raw[key] = resolved.value;
    index = resolved.nextIndex;
  }

  if (!raw.url) {
    throw new CliError('--url is required');
  }
  if (raw.requests === undefined) {
    throw new CliError('--requests is required');
  }
  if (raw.concurrency === undefined) {
    throw new CliError('--concurrency is required');
  }
  if (raw.timeout === undefined) {
    throw new CliError('--timeout is required');
  }

  return {
    options: normalizeOptions({
      url: raw.url,
      requests: parsePositiveInteger(raw.requests, '--requests'),
      concurrency: parsePositiveInteger(raw.concurrency, '--concurrency'),
      timeoutMs: parseDuration(raw.timeout),
    }),
  };
}

export function normalizeOptions(input) {
  if (!input || typeof input !== 'object') {
    throw new CliError('options are required');
  }

  if (typeof input.url !== 'string' || input.url.trim().length === 0) {
    throw new CliError('--url is required');
  }

  let target;
  try {
    target = new URL(input.url);
  } catch {
    throw new CliError('--url must be a valid absolute URL');
  }
  if (target.protocol !== 'http:' && target.protocol !== 'https:') {
    throw new CliError('--url must use http:// or https://');
  }

  if (!Number.isSafeInteger(input.requests) || input.requests <= 0) {
    throw new CliError('--requests must be a positive integer');
  }
  if (!Number.isSafeInteger(input.concurrency) || input.concurrency <= 0) {
    throw new CliError('--concurrency must be a positive integer');
  }
  if (
    typeof input.timeoutMs !== 'number'
    || !Number.isFinite(input.timeoutMs)
    || input.timeoutMs <= 0
    || input.timeoutMs > MAX_TIMER_MS
  ) {
    throw new CliError('--timeout must be greater than 0 and within the supported timer range');
  }

  return Object.freeze({
    url: target.toString(),
    requests: input.requests,
    requestedConcurrency: input.concurrency,
    concurrency: Math.min(input.concurrency, input.requests),
    timeoutMs: input.timeoutMs,
  });
}

function elapsedMilliseconds(startedAt) {
  return Number(process.hrtime.bigint() - startedAt) / 1_000_000;
}

async function discardResponseBody(response) {
  if (!response.body) {
    return;
  }

  const reader = response.body.getReader();
  try {
    while (true) {
      const { done } = await reader.read();
      if (done) {
        return;
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export async function executeRequest(url, timeoutMs, externalSignal, fetchImpl = globalThis.fetch) {
  const startedAt = process.hrtime.bigint();
  const requestController = new AbortController();
  let abortCause = null;

  const abortFromCaller = () => {
    if (abortCause === null) {
      abortCause = 'cancelled';
      requestController.abort(externalSignal.reason);
    }
  };

  if (externalSignal) {
    if (externalSignal.aborted) {
      return { kind: 'cancelled', latencyMs: elapsedMilliseconds(startedAt) };
    }
    externalSignal.addEventListener('abort', abortFromCaller, { once: true });
  }

  const timeoutHandle = setTimeout(() => {
    if (abortCause === null) {
      abortCause = 'timeout';
      requestController.abort(new Error(`request timed out after ${timeoutMs}ms`));
    }
  }, timeoutMs);

  try {
    const response = await fetchImpl(url, {
      method: 'GET',
      signal: requestController.signal,
    });
    await discardResponseBody(response);

    return {
      kind: response.status >= 200 && response.status <= 299 ? 'succeeded' : 'non2xx',
      latencyMs: elapsedMilliseconds(startedAt),
    };
  } catch (error) {
    if (abortCause === 'timeout') {
      return { kind: 'timeout', latencyMs: elapsedMilliseconds(startedAt) };
    }
    if (abortCause === 'cancelled') {
      return { kind: 'cancelled', latencyMs: elapsedMilliseconds(startedAt) };
    }
    return { kind: 'error', latencyMs: elapsedMilliseconds(startedAt), error };
  } finally {
    clearTimeout(timeoutHandle);
    externalSignal?.removeEventListener('abort', abortFromCaller);
  }
}

export async function runLoadTest(inputOptions, { signal, fetchImpl = globalThis.fetch } = {}) {
  const options = normalizeOptions({
    url: inputOptions.url,
    requests: inputOptions.requests,
    concurrency: inputOptions.requestedConcurrency ?? inputOptions.concurrency,
    timeoutMs: inputOptions.timeoutMs,
  });

  const stats = {
    scheduled: 0,
    completed: 0,
    succeeded: 0,
    non2xx: 0,
    errors: 0,
    timeouts: 0,
    cancelled: 0,
    active: 0,
    peakConcurrency: 0,
    latencyTotalMs: 0,
    latencyMinMs: Number.POSITIVE_INFINITY,
    latencyMaxMs: 0,
  };
  let nextRequest = 0;
  const runStartedAt = process.hrtime.bigint();

  const recordCompleted = (outcome) => {
    const counterByOutcome = {
      succeeded: 'succeeded',
      non2xx: 'non2xx',
      error: 'errors',
      timeout: 'timeouts',
    };
    stats.completed += 1;
    stats[counterByOutcome[outcome.kind]] += 1;
    stats.latencyTotalMs += outcome.latencyMs;
    stats.latencyMinMs = Math.min(stats.latencyMinMs, outcome.latencyMs);
    stats.latencyMaxMs = Math.max(stats.latencyMaxMs, outcome.latencyMs);
  };

  const worker = async () => {
    while (!signal?.aborted && nextRequest < options.requests) {
      // This claim is synchronous. JavaScript cannot interleave another worker here.
      nextRequest += 1;
      stats.scheduled += 1;
      stats.active += 1;
      stats.peakConcurrency = Math.max(stats.peakConcurrency, stats.active);

      const outcome = await executeRequest(options.url, options.timeoutMs, signal, fetchImpl);
      stats.active -= 1;

      if (outcome.kind === 'cancelled') {
        stats.cancelled += 1;
      } else {
        recordCompleted(outcome);
      }
    }
  };

  // Only `concurrency` workers are created, regardless of the total request count.
  await Promise.all(Array.from({ length: options.concurrency }, () => worker()));

  const totalElapsedMs = elapsedMilliseconds(runStartedAt);
  return {
    target: options.url,
    requests: options.requests,
    requestedConcurrency: options.requestedConcurrency,
    concurrency: options.concurrency,
    timeoutMs: options.timeoutMs,
    interrupted: Boolean(signal?.aborted),
    scheduled: stats.scheduled,
    completed: stats.completed,
    succeeded: stats.succeeded,
    non2xx: stats.non2xx,
    errors: stats.errors,
    timeouts: stats.timeouts,
    cancelled: stats.cancelled,
    peakConcurrency: stats.peakConcurrency,
    elapsedMs: totalElapsedMs,
    requestsPerSecond: totalElapsedMs > 0 ? stats.completed / (totalElapsedMs / 1_000) : 0,
    averageLatencyMs: stats.completed > 0 ? stats.latencyTotalMs / stats.completed : null,
    minLatencyMs: stats.completed > 0 ? stats.latencyMinMs : null,
    maxLatencyMs: stats.completed > 0 ? stats.latencyMaxMs : null,
  };
}

function reportLine(label, value) {
  return `${`${label}:`.padEnd(18)}${value}`;
}

function formatLatency(value) {
  return value === null ? 'N/A' : `${value.toFixed(2)}ms`;
}

export function formatReport(result) {
  const concurrency = result.requestedConcurrency === result.concurrency
    ? String(result.concurrency)
    : `${result.concurrency} (requested ${result.requestedConcurrency}; capped to request count)`;

  return [
    reportLine('Target', result.target),
    reportLine('Requests', result.requests),
    reportLine('Concurrency', concurrency),
    reportLine('Timeout', `${result.timeoutMs}ms`),
    '',
    reportLine('Interrupted', result.interrupted),
    reportLine('Scheduled', result.scheduled),
    reportLine('Completed', result.completed),
    reportLine('Succeeded', result.succeeded),
    reportLine('Non-2xx', result.non2xx),
    reportLine('Errors', result.errors),
    reportLine('Timeouts', result.timeouts),
    reportLine('Cancelled', result.cancelled),
    '',
    reportLine('Elapsed', `${(result.elapsedMs / 1_000).toFixed(3)}s`),
    reportLine('Requests/sec', result.requestsPerSecond.toFixed(2)),
    reportLine('Avg latency', formatLatency(result.averageLatencyMs)),
    reportLine('Min latency', formatLatency(result.minLatencyMs)),
    reportLine('Max latency', formatLatency(result.maxLatencyMs)),
  ].join('\n');
}

export function usage() {
  return `httpload - bounded-concurrency HTTP GET load tester

Usage:
  httpload --url <URL> --requests <N> --concurrency <N> --timeout <DURATION>

Options:
  -u, --url           Target HTTP or HTTPS URL
  -n, --requests      Total number of requests (positive integer)
  -c, --concurrency   Maximum in-flight requests (positive integer)
  -t, --timeout       Per-request timeout: ms, s, or m (for example 500ms, 2s)
  -h, --help          Show this help
  -v, --version       Show the version

Example:
  httpload -u http://localhost:8080/ -n 1000 -c 20 -t 2s`;
}

export async function main(
  argv = process.argv.slice(2),
  { stdout = process.stdout, stderr = process.stderr } = {},
) {
  let parsed;
  try {
    parsed = parseCliArgs(argv);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    stderr.write(`Error: ${message}\n\n${usage()}\n`);
    return 2;
  }

  if (parsed.help) {
    stdout.write(`${usage()}\n`);
    return 0;
  }
  if (parsed.version) {
    stdout.write('httpload 1.0.0\n');
    return 0;
  }

  const controller = new AbortController();
  const handleInterrupt = () => {
    if (!controller.signal.aborted) {
      stderr.write('\nInterrupt received; cancelling in-flight requests...\n');
      controller.abort(new Error('interrupted by user'));
    }
  };
  process.once('SIGINT', handleInterrupt);

  try {
    const result = await runLoadTest(parsed.options, { signal: controller.signal });
    stdout.write(`${formatReport(result)}\n`);
    return result.interrupted ? 130 : 0;
  } catch (error) {
    const message = error instanceof Error ? error.stack ?? error.message : String(error);
    stderr.write(`Fatal error: ${message}\n`);
    return 1;
  } finally {
    process.removeListener('SIGINT', handleInterrupt);
  }
}
