import assert from 'node:assert/strict';
import http from 'node:http';
import { afterEach, describe, test } from 'node:test';

import {
  CliError,
  normalizeOptions,
  parseCliArgs,
  parseDuration,
  runLoadTest,
} from '../src/httpload.js';

const openServers = new Set();

async function startServer(handler) {
  const server = http.createServer(handler);
  openServers.add(server);
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  return {
    server,
    url: `http://127.0.0.1:${address.port}/`,
  };
}

async function stopServer(server) {
  if (!server.listening) {
    openServers.delete(server);
    return;
  }

  const closed = new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
  server.closeAllConnections?.();
  await closed;
  openServers.delete(server);
}

afterEach(async () => {
  await Promise.all([...openServers].map((server) => stopServer(server)));
});

describe('argument handling', () => {
  test('parses supported duration units and caps concurrency to request count', () => {
    assert.equal(parseDuration('500ms'), 500);
    assert.equal(parseDuration('1.5s'), 1_500);
    assert.equal(parseDuration('2m'), 120_000);

    const parsed = parseCliArgs([
      '--url=http://localhost:8080/',
      '--requests', '3',
      '--concurrency', '10',
      '--timeout', '2s',
    ]);
    assert.equal(parsed.options.requestedConcurrency, 10);
    assert.equal(parsed.options.concurrency, 3);
  });

  test('rejects invalid values', () => {
    assert.throws(() => parseDuration('0s'), CliError);
    assert.throws(() => parseDuration('soon'), CliError);
    assert.throws(
      () => parseCliArgs(['--requests', '1', '--concurrency', '1', '--timeout', '1s']),
      /--url is required/,
    );
    assert.throws(
      () => parseCliArgs(['--url', 'not-a-url', '--requests', '1', '--concurrency', '1', '--timeout', '1s']),
      /valid absolute URL/,
    );
    assert.throws(
      () => normalizeOptions({ url: 'ftp://example.com', requests: 1, concurrency: 1, timeoutMs: 10 }),
      /http:\/\/ or https:\/\//,
    );
    assert.throws(
      () => parseCliArgs(['--url', 'http://localhost', '--requests', '0', '--concurrency', '1', '--timeout', '1s']),
      /positive integer/,
    );
    assert.throws(
      () => parseCliArgs(['--url', 'http://localhost', '--requests', '1', '--concurrency', '0', '--timeout', '1s']),
      /positive integer/,
    );
    assert.throws(
      () => parseCliArgs(['--url', 'http://localhost', '--requests', '1', '--concurrency', '1', '--timeout', '0ms']),
      /greater than 0/,
    );
  });
});

test('executes the exact request count without exceeding concurrency', async () => {
  let received = 0;
  let active = 0;
  let peakActive = 0;
  const { server, url } = await startServer((_request, response) => {
    received += 1;
    active += 1;
    peakActive = Math.max(peakActive, active);
    response.once('close', () => {
      active -= 1;
    });
    setTimeout(() => {
      response.writeHead(204);
      response.end();
    }, 20);
  });

  const result = await runLoadTest({ url, requests: 25, concurrency: 4, timeoutMs: 1_000 });
  await stopServer(server);

  assert.equal(received, 25);
  assert.ok(peakActive <= 4, `observed ${peakActive} concurrent requests`);
  assert.ok(result.peakConcurrency <= 4);
  assert.equal(result.scheduled, 25);
  assert.equal(result.completed, 25);
  assert.equal(result.succeeded, 25);
  assert.equal(result.completed, result.succeeded + result.non2xx + result.errors + result.timeouts);
});

test('classifies 2xx and non-2xx responses', async () => {
  let received = 0;
  const { server, url } = await startServer((_request, response) => {
    received += 1;
    response.writeHead(received <= 6 ? 200 : 503, { 'content-type': 'text/plain' });
    response.end('discarded response body');
  });

  const result = await runLoadTest({ url, requests: 10, concurrency: 3, timeoutMs: 1_000 });
  await stopServer(server);

  assert.equal(result.succeeded, 6);
  assert.equal(result.non2xx, 4);
  assert.equal(result.errors, 0);
  assert.equal(result.timeouts, 0);
  assert.equal(result.completed, 10);
});

test('keeps all four completed outcome categories mutually exclusive and conserved', async () => {
  let received = 0;
  const { server, url } = await startServer((_request, response) => {
    const outcome = received % 4;
    received += 1;

    if (outcome === 0) {
      response.writeHead(200);
      response.end('ok');
    } else if (outcome === 1) {
      response.writeHead(404);
      response.end('missing');
    } else if (outcome === 2) {
      response.socket.destroy();
    } else {
      setTimeout(() => {
        response.writeHead(200);
        response.end('late');
      }, 100);
    }
  });

  const result = await runLoadTest({ url, requests: 20, concurrency: 4, timeoutMs: 20 });
  await stopServer(server);

  assert.equal(result.scheduled, 20);
  assert.equal(result.completed, 20);
  assert.equal(result.succeeded, 5);
  assert.equal(result.non2xx, 5);
  assert.equal(result.errors, 5);
  assert.equal(result.timeouts, 5);
  assert.ok(result.peakConcurrency <= 4);
  assert.equal(result.completed, result.succeeded + result.non2xx + result.errors + result.timeouts);
});

test('counts slow requests as timeouts without deadlocking', async () => {
  const { server, url } = await startServer((_request, response) => {
    setTimeout(() => {
      response.writeHead(200);
      response.end('too late');
    }, 150);
  });

  const result = await runLoadTest({ url, requests: 6, concurrency: 2, timeoutMs: 25 });
  await stopServer(server);

  assert.equal(result.completed, 6);
  assert.equal(result.timeouts, 6);
  assert.equal(result.succeeded, 0);
  assert.ok(result.peakConcurrency <= 2);
  assert.equal(result.completed, result.succeeded + result.non2xx + result.errors + result.timeouts);
});

test('applies timeout while streaming the response body', async () => {
  const { server, url } = await startServer((_request, response) => {
    response.writeHead(200);
    response.write('partial body');
    setTimeout(() => response.end('too late'), 100);
  });

  const result = await runLoadTest({ url, requests: 3, concurrency: 1, timeoutMs: 20 });
  await stopServer(server);

  assert.equal(result.completed, 3);
  assert.equal(result.succeeded, 0);
  assert.equal(result.timeouts, 3);
  assert.ok(result.peakConcurrency <= 1);
});

test('counts network failures as errors', async () => {
  const { server, url } = await startServer((request) => {
    request.socket.destroy();
  });

  const result = await runLoadTest({ url, requests: 5, concurrency: 2, timeoutMs: 1_000 });
  await stopServer(server);

  assert.equal(result.completed, 5);
  assert.equal(result.errors, 5);
  assert.equal(result.timeouts, 0);
});

test('aborting stops scheduling and cancels in-flight requests', async () => {
  const { server, url } = await startServer((_request, response) => {
    setTimeout(() => {
      response.writeHead(200);
      response.end('late');
    }, 500);
  });
  const controller = new AbortController();
  setTimeout(() => controller.abort(new Error('test interrupt')), 40);

  const result = await runLoadTest(
    { url, requests: 100, concurrency: 5, timeoutMs: 2_000 },
    { signal: controller.signal },
  );
  await stopServer(server);

  assert.equal(result.interrupted, true);
  assert.ok(result.scheduled > 0 && result.scheduled <= 5);
  assert.equal(result.scheduled, result.completed + result.cancelled);
  assert.equal(result.completed, result.succeeded + result.non2xx + result.errors + result.timeouts);
  assert.equal(result.completed, 0);
  assert.equal(result.averageLatencyMs, null);
  assert.equal(result.minLatencyMs, null);
  assert.equal(result.maxLatencyMs, null);
});

test('latency statistics include completed requests and exclude cancelled requests', async () => {
  let calls = 0;
  const fetchImpl = (_url, { signal }) => {
    calls += 1;
    if (calls === 1) {
      return Promise.resolve({ status: 204, body: null });
    }

    return new Promise((_resolve, reject) => {
      const rejectOnAbort = () => reject(signal.reason ?? new Error('aborted'));
      if (signal.aborted) {
        rejectOnAbort();
      } else {
        signal.addEventListener('abort', rejectOnAbort, { once: true });
      }
    });
  };
  const controller = new AbortController();
  setTimeout(() => controller.abort(new Error('test interrupt')), 20);

  const result = await runLoadTest(
    { url: 'http://local.test/', requests: 100, concurrency: 3, timeoutMs: 1_000 },
    { signal: controller.signal, fetchImpl },
  );

  assert.equal(result.completed, 1);
  assert.equal(result.succeeded, 1);
  assert.equal(result.scheduled, result.completed + result.cancelled);
  assert.ok(result.cancelled > 0);
  assert.ok(result.peakConcurrency <= 3);
  assert.notEqual(result.averageLatencyMs, null);
  assert.equal(result.averageLatencyMs, result.minLatencyMs);
  assert.equal(result.averageLatencyMs, result.maxLatencyMs);
});
